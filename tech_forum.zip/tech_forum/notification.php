<?php require("header.php");?>
<?php
echo "<h1> YOU ARE REGISTERED </h1> " ;
echo "click here to log-in <a href='index.php'>click here</a>";
?>
<?php require("footer.php");?>