<?php session_start();
 require("header.php");
 require ("checkUser.php")?>
 <h1>Your Profile Is Successfully Updated  </h1>
 <?php require("footer.php")?>