<?php 
session_start();
require("header.php");
require("checkUser.php");
?>
<h4>successfully sent message</h4>

<?php require("footer.php")?>